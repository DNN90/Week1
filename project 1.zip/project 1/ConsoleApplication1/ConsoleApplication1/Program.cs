﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Shape
    {
        protected int width;
        protected int height;
        protected int radius;

        public void setvalues(int w, int h, int r)
        {
            width = w;
            height = h;
            radius = r;
        }
    }

    //Derived Class//
    class Rectangle : Shape
    {
        public int getArea()
        {
            return (width * height);
        }

        public int getPerimeter()
        {
            return (2*(width + height));
        }
    }

    class Circle : Shape
    {
        public float getCArea()
        {
            return ((22/7)*((radius)^2));
        }

        public float getCPerimeter()
        {
            return (2*(22/7)*(radius));
        }
    }

    class ShapeTester
    {
        static void Main(string[] args)
        {
            Rectangle Rect = new Rectangle();
            Console.WriteLine("Enter the length:");
            int x = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the width:");
            int y = Convert.ToInt32(Console.ReadLine());
            int z = 0;

            Rect.setvalues(x, y, z);
            //Rect.setWidth(x)//
            //Rect.setHeight(y)//

            //Print the area of the object//
            Console.WriteLine("Total area: {0}", Rect.getArea());
            Console.WriteLine("Total perimeter: {0}", Rect.getPerimeter());
            Console.ReadLine();



            Circle Circ = new Circle();
            int a = 0;
            int b = 0;
            Console.WriteLine("Enter the radius:");
            int c = Convert.ToInt32(Console.ReadLine());
            

            Circ.setvalues(a, b, c);
            //Circ.setRadius(c)//

            //Print the area of the object//
            Console.WriteLine("Total Circle area: {0}", Circ.getCArea());
            Console.WriteLine("Total Circle perimeter: {0}", Circ.getCPerimeter());
            Console.ReadLine();

        }
    }
}
